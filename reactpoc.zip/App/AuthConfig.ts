import { Configuration, PopupRequest } from "@azure/msal-browser";

// Config Azure AD app setting to be passed to Msal on creation
const TenantId = "aaa84a15-b2b5-416c-bd8c-f38061901129";
const ClientId = "d6590368-4a63-44fe-97a3-91d321181fb2";

export const msalConfig: Configuration = {
    auth: {
        clientId: ClientId,
        authority: "https://login.microsoftonline.com/" + TenantId,
        redirectUri: "/",
        postLogoutRedirectUri: "/"        
    }
};

export const PowerBiPermissionScopes: string[] = [
    'https://analysis.windows.net/powerbi/api/.default'
    // "https://analysis.windows.net/powerbi/api/Dashboard.Read.All",
    // "https://analysis.windows.net/powerbi/api/Dataset.Read.All",
    // "https://analysis.windows.net/powerbi/api/Report.ReadWrite.All",
    // "https://analysis.windows.net/powerbi/api/Group.Read.All",
    // "https://analysis.windows.net/powerbi/api/Workspace.ReadWrite.All",
    // "https://analysis.windows.net/powerbi/api/Content.Create"
  ]

export const PowerBiLoginRequest: PopupRequest = {
    scopes: PowerBiPermissionScopes
};