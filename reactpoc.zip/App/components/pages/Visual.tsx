import React, { useEffect, useState } from 'react';

import { PowerBIEmbed } from 'powerbi-client-react';
import { models } from 'powerbi-client';
import PowerBiService from '../../services/PowerBiService'
import { Container } from '@mui/material';

function View2() {
    const [report, setReport] = useState({ id: '', embedUrl: '', name: '' });
    const [accessToken, setAccessToken] = useState('');

    const getReportInfo = async () => {
        const accessToken = await PowerBiService.GetAccessToken()
        const report = await PowerBiService.GetReport('b81f2141-5e27-489e-8d87-d506b1e3a3ab', '239129af-6bbb-457f-8a8c-f03cff704af9')
        const datasource = await PowerBiService.GetDataSources('239129af-6bbb-457f-8a8c-f03cff704af9')

        setAccessToken(accessToken)
        setReport(report)
        console.log({ datasource })
    }

    useEffect(() => {
        getReportInfo()
    }, [])

    return (
        <Container maxWidth={false}>
            <PowerBIEmbed
                embedConfig={{
                    type: 'visual',
                    id: report.id, // Replace with your report id if necessary
                    embedUrl: report.embedUrl,
                    pageName: 'ReportSectione0912ffb2ba909ea50d0',
                    visualName: 'b3ce93b93cba452a50d4',
                    accessToken: accessToken,
                    tokenType: models.TokenType.Aad,
                    permissions: models.Permissions.Read,
                    settings: {
                        filterPaneEnabled: false,
                        navContentPaneEnabled: false,
                    },
                }}
                cssClassName="embed-container"
                getEmbeddedComponent={(embeddedReport) => {
                }}
            />
        </Container>
    );
}

export default View2;