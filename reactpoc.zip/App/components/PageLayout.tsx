import { Route, Routes } from "react-router-dom";
import Banner from './Banner';
import Home from './pages/Home';
import Report from './pages/Report';
import Visual from './pages/Visual';
import CustomVisual from './pages/CustomVisual';
import PageNotFound from './PageNotFound';
import LeftNav from './LeftNav';
import { Box } from '@mui/material';
import { useIsAuthenticated } from "@azure/msal-react";

const PageLayout = () => {
     const isAuthenticated = useIsAuthenticated();

    return (
        <Box>
            <Banner />
            <Box sx={{ display: "flex", flexDirection:'row' }} >
                {isAuthenticated && <LeftNav />}
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/report" element={<Report />} />
                    <Route path="/visual" element={<Visual />} />
                    <Route path="/custom-visual" element={<CustomVisual />} />
                    <Route path="*" element={<PageNotFound />} />
                </Routes>
            </Box>
        </Box>
    )
}

export default PageLayout