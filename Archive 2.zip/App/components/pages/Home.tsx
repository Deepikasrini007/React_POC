import React from 'react';
import { useIsAuthenticated } from "@azure/msal-react";
import { Container, Typography, Alert } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const isAuthenticated = useIsAuthenticated();
  const navigate = useNavigate();

  if (isAuthenticated) {
    navigate("report")
    return <></>

  }
  else {
    return (
      <Container maxWidth={false}>
        <Typography variant='h5' component="h2" sx={{ my: 3 }} >Welcome to the Power BI Embedded (user owns data)</Typography>
        <Alert sx={{ border:1, padding: 2, mx: 2 }} severity='info' >Click the <strong>LOGIN</strong> button in the upper right to get started.</Alert>
        </Container>
    )
  }
}

export default Home;