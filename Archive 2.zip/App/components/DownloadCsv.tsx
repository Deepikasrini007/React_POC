import React from 'react';
import { IconButton } from '@mui/material';
import { Download } from '@mui/icons-material'


function downloadJSONAsCSV(jsonData: any) {
    // Convert JSON data to CSV
    let csvData = jsonToCsv(jsonData);
    // Create a CSV file and allow the user to download it
    let blob = new Blob([csvData], { type: 'text/csv' });
    let url = window.URL.createObjectURL(blob);
    let a = document.createElement('a');
    a.href = url;
    a.download = 'data.csv';
    document.body.appendChild(a);
    a.click();
}
function jsonToCsv(jsonData: any) {
    let csv = '';
    // Get the headers
    let headers = Object.keys(jsonData[0]);
    csv += headers.join(',') + '\n';
    // Add the data
    jsonData.forEach(function (row: any) {
        let data = headers.map(header => JSON.stringify(row[header])).join(','); // Add JSON.stringify statement
        csv += data + '\n';
    });
    return csv;
}



const DownloadCsv = ({ data }: { data: any }) => {
    return (
        <IconButton sx={{ width: "400px", color: '#33c481', display: 'flex', justifyContent: 'flex-start', alignItems: 'flex-start', fontSize: '18px' }} onClick={() => { downloadJSONAsCSV(data) }}><Download />{`Export as csv`}</IconButton>
    );
}

export default DownloadCsv;