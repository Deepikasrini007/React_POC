# Modern-React-For-PowerBI
A sample SPA implementing User-Owns-Data embedding using React-JS with functional components and hooks.
