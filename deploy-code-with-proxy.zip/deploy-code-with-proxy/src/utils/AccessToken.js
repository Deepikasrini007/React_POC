// // auth.js
// import axios from 'axios';
// import data from '../ui-components/constants.json';

// const tenantId = data.tenantId;
// const clientId = data.clientId;
// const clientSecret = data.clientSecret;
// const authority = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;
// const resource = 'https://analysis.windows.net/powerbi/api';
// const resource2 = 'https://analysis.windows.net/powerbi/api/.default';
// const resource1 = 'api://d6590368-4a63-44fe-97a3-91d321181fb2/.default';

// export const getAccessToken = async () => {
//     const params = new URLSearchParams();
//     params.append('grant_type', 'client_credentials');
//     params.append('client_id', clientId);
//     params.append('client_secret', clientSecret);
//     params.append('scope', resource2);
  
//     try {
//       const response = await axios.post(authority, params, {
//         headers: {
//           'Content-Type': 'application/x-www-form-urlencoded'
//         }
//       });
//       return response.data.access_token;
//     } catch (error) {
//       console.error('Error fetching access token:', error);
//       throw error;
//     }
// };

import axios from 'axios';

export const getAccessToken = async () => {
  try {
    const response = await axios.get(`${process.env.REACT_APP_NODE_API_ENDPOINT_URL}/api/embed-info`);
    console.log(response, 'response123');
    return response.data;
  } catch (error) {
    console.error('Error fetching access token:', error.response?.data || error.message);
    throw error;
  }
};


