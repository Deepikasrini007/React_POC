import React, { useEffect, useState } from 'react';

import { PowerBIEmbed } from 'powerbi-client-react';
import { models } from 'powerbi-client';

import axios from 'axios';
import data from './constants.json';
import { getAccessToken } from '../utils/AccessToken';


function View1() {
    // console.log(accessToken, 'view1');
    const [embedURL, setEmbedURL] = useState('');
    const [ accessToken, setAccessToken] = useState('');

    // useEffect(() => {
    //     axios.get(`https://api.powerbi.com/v1.0/myorg/groups/${data.groupId}/reports/${data.reportId}`, {
    //         headers: {
    //             'Content-Type': 'application/json',
    //             'Authorization': `Bearer ${accessToken}`
    //         }
    //     }).then(res => {
    //         console.log(res.data, 'arun10')
    //         setEmbedURL(res.data.embedUrl);
    //     }).catch(err => {
    //         console.log(err, 'arun2');
    //     })
    // }, [accessToken])

    useEffect(() => {
        const fetchAccessToken = async () => {
            try {
              const res = await getAccessToken();
              console.log(res, 'token123');
              setAccessToken(res.embedToken);
              setEmbedURL(res.embedUrl);
            } catch (error) {
              console.error('Error fetching access token:', error);
            }
          };
      
          fetchAccessToken();

    }, []);

    if (!accessToken || !embedURL) {
        return (<h2>Loading....</h2>)
    }
    

  return (
        // <PowerBIEmbed
        //     embedConfig={{
        //     type: 'report',   // Supported types: report, dashboard, tile, visual, qna, paginated report and create
        //     id: data.reportId,
        //     //pageName: 'ReportSectione0912ffb2ba909ea50d0',
        //     //visualName:'VisualContainer4',
        //     embedUrl: embedURL,
        //     accessToken: accessToken,
        //     tokenType: models.TokenType.Aad, // Use models.TokenType.Aad for SaaS embed
        //     settings: {
        //         panes: {
        //         filters: {
        //             expanded: false,
        //             visible: true
        //         }
        //         }
        //     }
        //     }}

        //     eventHandlers={
        //     new Map([
        //         ['loaded', function () { console.log('Report loaded'); }],
        //         ['rendered', function () { 
        //             console.log('Report rendered'); 
        //         }],
        //         ['error', function (event) { console.log(event.detail); }],
        //         ['visualClicked', () => console.log('visual clicked')],
        //         ['pageChanged', (event) => console.log(event)],
        //     ])
        //     }

        //     cssClassName={"Embed-container"}

        //     getEmbeddedComponent={(embeddedReport) => {
        //     window.report = embeddedReport ;
        //     }}
        // />

        <PowerBIEmbed
            embedConfig={{
                type: 'report',
                id: data.reportId,
                embedUrl: embedURL,
                accessToken: accessToken,
                tokenType: models.TokenType.Embed,
                settings: {
                filterPaneEnabled: false,
                navContentPaneEnabled: false,
                },
            }}
            cssClassName="embed-container"
            getEmbeddedComponent={(embeddedReport) => {
                window.report = embeddedReport;
            }}
            style={{ height: '600px' }}
        />
  );
}

export default View1; 