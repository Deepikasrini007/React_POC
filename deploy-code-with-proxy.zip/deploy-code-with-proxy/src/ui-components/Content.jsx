import React from 'react';
import { GridColumn, Grid, Button, GridRow } from 'semantic-ui-react'
import Sidebar from './Sidebar';
import View1 from './View1';
import View2 from './View2';
import View3 from './View3';
// import PowerBIReport from './PowerBiReport';
import PowerBIReport from './Final';

function Content(props) {
    const { activeView, accessToken } = props;
    return (
        <Grid>
            <GridRow>
                <GridColumn width={1}>
                    <Sidebar />
                </GridColumn>
                <GridColumn width={15}>
                <div style={{ marginTop: '10px', marginBottom: '20px' }}>
                    <Button content='Home' primary style={{ marginRight: '0px' }} />
                    <Button content='Details' />
                </div>

                {activeView === 'nfcm' && (<View1 accessToken={accessToken} />)}
                {activeView === 'internal_audit' && (<View2 />)}
                {activeView === 'enablon' && (<View3 accessToken={accessToken} />)}

                </GridColumn>
            </GridRow>
        </Grid>
    )
}

export default Content;