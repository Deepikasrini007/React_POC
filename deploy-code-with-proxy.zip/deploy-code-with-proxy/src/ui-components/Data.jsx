// import './App.css';
import './Data.css';
import React , { useState } from 'react';
import Content from './Content';
import Filters from './Filters';
import MenuHeader from './Header';

function Data({ accessToken }) {
  const [activeView, setActiveView] = useState('nfcm');
  return (
    <>
      <MenuHeader 
        activeView={activeView} 
        setActiveView={setActiveView} 
      />
      <Filters />
      <Content 
        activeView={activeView} 
        accessToken={accessToken}
      />
    </>
  );
}

export default Data;
