// PowerBIReport.js
import React, { useEffect, useState } from 'react';
import { useMsal, useAccount } from '@azure/msal-react';
import { PowerBIEmbed } from 'powerbi-client-react';
import { models } from 'powerbi-client';
// import { loginRequest } from './authConfig';
import axios from 'axios';
import constants from './constants.json'

const msalConfig = {
    auth: {
        clientId: process.env.REACT_APP_CLIENT_ID,
        authority: `https://login.microsoftonline.com/${process.env.REACT_APP_TENANT_ID}`,
        redirectUri: process.env.REACT_APP_REDIRECT_URI,
    },
    cache: {
        cacheLocation: 'localStorage', // This configures where your cache will be stored
        storeAuthStateInCookie: false, // Set this to "true" if you are having issues on IE11 or Edge
    }
};
  
const loginRequest = {
scopes: ["https://analysis.windows.net/powerbi/api/.default"]
};

const PowerBIReport = ({ accessToken }) => {
  const { instance, accounts } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [embedConfig, setEmbedConfig] = useState(null);
  const [loading, setLoading] = useState(true);

  

  useEffect(() => {
    const fetchEmbedInfo = async () => {
      try {
        if (account) {
        //   const response = await instance.acquireTokenSilent({
        //     ...loginRequest,
        //     account: account,
        //   });

        //   const accessToken = response.accessToken;

          const embedInfoResponse = await axios.get(`${process.env.REACT_APP_NODE_API_ENDPOINT_URL}/api/embed-info`, {
            headers: {
              Authorization: `Bearer ${accessToken}`,
            },
          });

          console.log(embedInfoResponse.data, 'token from node server')
          console.log('token from msal auth', accessToken)

        //   const embedInfo = await embedInfoResponse.json();
        //   console.log(embedInfo, 'embedInfo123');

        console.log('HELLOWORLD123456', models.TokenType.Aad);

          setEmbedConfig({
            id: constants.reportId,
            accessToken: accessToken,
            embedUrl: embedInfoResponse.data.embedUrl,
            type: 'report',
            tokenType: models.TokenType.Aad,
            settings: {
              panes: {
              filters: {
                  expanded: false,
                  visible: true
              }
              }
            }
          });

          setLoading(false);
        }
      } catch (error) {
        setLoading(true)
        console.error('Error fetching embed info:', error);
      }
    };

    fetchEmbedInfo();
  }, [instance, account]);

  console.log(embedConfig, 'embedConfig')

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="report-container">
      <PowerBIEmbed
        embedConfig={embedConfig}
        cssClassName="embed-container"
        getEmbeddedComponent={(embeddedReport) => {
          window.report = embeddedReport;
        }}
      />
    </div>
  );
};

export default PowerBIReport;
