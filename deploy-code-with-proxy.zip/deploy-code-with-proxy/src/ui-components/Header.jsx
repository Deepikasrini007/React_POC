import React from 'react';
import { MenuItem, Menu, Segment, Icon } from 'semantic-ui-react';

function MenuHeader(props) {
    const { activeView, setActiveView } = props;
    const handleItemClick = (e, { name }) => setActiveView(name);

    return (
        <Segment pointing attached size='mini' style={{ backgroundColor: '#fff' }}>
            <Menu inverted secondary>
                <Menu.Item
                    name='nfcm'
                    active={activeView === 'logo'}
                    onClick={handleItemClick}
                >
                    {/* <img 
                        src="./logo.png"  
                        alt="Novartis logo"
                        style={{ width: '100px' }}
                    /> */}
                    Home
                </Menu.Item>
                <Menu.Menu pointing secondary position='right'>
                    <MenuItem
                        name='nfcm'
                        active={activeView === 'nfcm'}
                        onClick={handleItemClick}
                        className='menu-item'
                    >
                        Embedded Report
                        </MenuItem>
                    <MenuItem
                        name='internal_audit'
                        active={activeView === 'internal_audit'}
                        onClick={handleItemClick}
                        className='menu-item'
                    >
                        Embedded Visual
                    </MenuItem>
                    <MenuItem
                        name='enablon'
                        active={activeView === 'enablon'}
                        onClick={handleItemClick}
                        className='menu-item'
                    >
                        React Visual
                    </MenuItem>
                </Menu.Menu>
                
                <Menu.Item
                    active={activeView === 'login'}
                    onClick={handleItemClick}
                    position="right"
                    className='menu-icon'
                >
                    <Icon disabled name='download' style={{ color: '#000' }} />
                </Menu.Item>
                <Menu.Item className='menu-icon'>
                    <Icon disabled name='star outline' style={{ color: '#000' }} />
                </Menu.Item>
                <Menu.Item className='menu-icon'>
                    <Icon disabled name='redo' style={{ color: '#000' }} />
                </Menu.Item>
                <Menu.Item className='menu-icon'>
                    <Icon disabled name='copy outline' style={{ color: '#000' }} />
                </Menu.Item>
                <Menu.Item
                    name='sign_in'
                    active={activeView === 'sign_in'}
                    onClick={handleItemClick}
                >
                    Embedded Analytics
                </Menu.Item>
                
            {/* section */}
            </Menu>
      </Segment>

    );
}

export default MenuHeader;