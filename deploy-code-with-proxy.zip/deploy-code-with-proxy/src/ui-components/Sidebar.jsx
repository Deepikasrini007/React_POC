import React, { useState } from 'react';
import { MenuItem, Icon, Menu } from 'semantic-ui-react'


function Sidebar() {
    const [activeFilter, setActiveFilter] = useState('');
    return (
        <Menu icon vertical>
            <MenuItem
                name='filter'
                active={activeFilter === 'filter'}
                onClick={() => {}}
            >
                <Icon name='filter' />
            </MenuItem>

            <MenuItem
                name='folder'
                active={activeFilter === 'folder'}
                onClick={() => {}}
            >
                <Icon name='folder' />
            </MenuItem>

            <MenuItem
                name='calendar'
                active={activeFilter === 'calendar'}
                onClick={() => {}}
            >
                <Icon name='calendar alternate outline' />
            </MenuItem>
      </Menu>
    )
}

export default Sidebar;