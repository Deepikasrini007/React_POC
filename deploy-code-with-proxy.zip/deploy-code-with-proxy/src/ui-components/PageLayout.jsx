import Typography from "@mui/material/Typography";
import NavBar from "./NavBar";

export const PageLayout = (props) => {
    return (
        <>
            <NavBar />
            {/* <Typography variant="h5" style={{ marginTop: '35px' }}>
                <center>Welcome to the Contoro Application</center>
            </Typography> */}
            <br/>
            <br/>
            {props.children}
        </>
    );
};