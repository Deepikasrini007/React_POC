// PowerBIReport.js
import React, { useEffect, useState } from 'react';
import { PowerBIEmbed } from 'powerbi-client-react';
import { MsalProvider, AuthenticationResult, PublicClientApplication } from '@azure/msal-browser';
import data from './constants.json'
import axios from 'axios';

const PowerBIReport = ({ accessToken }) => {
  const [embedConfig, setEmbedConfig] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchEmbedInfo = async () => {
        console.log('arunbbbbb')
      try {
    //     const msalConfig = {
    //       auth: {
    //         clientId: data.clientId, // Replace with your Azure AD client ID
    //         authority: `https://login.microsoftonline.com/${data.tenantId}`, // Replace with your Azure AD tenant ID
    //         redirectUri: 'http://localhost:3000', // Replace with your redirect URI
    //       },
    //       cache: {
    //         cacheLocation: 'sessionStorage',
    //         storeAuthStateInCookie: false,
    //       },
    //     };

    //     const pca = new PublicClientApplication(msalConfig);

    //     const accounts = pca.getAllAccounts();
    //     const silentRequest = {
    //       scopes: ['openid', 'profile', 'User.Read'],
    //       account: accounts[0],
    //     };

    //     let response = await pca.acquireTokenSilent(silentRequest);
    //     const accessToken = response.accessToken;

        // console.log(response, 'arunbbbbb')
        console.log(accessToken, 'lllllllll')
        const embedInfoResponse = await axios.get(`${process.env.REACT_APP_NODE_API_ENDPOINT_URL}/api/embed-info`, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        });

        const embedInfo = await embedInfoResponse.json();

        console.log(embedInfo, 'embedInfo123');

        setEmbedConfig({
          accessToken,
          embedUrl: embedInfo.embedUrl,
          type: 'report',
          tokenType: 'AAD',
          settings: {
            filterPaneEnabled: false,
            navContentPaneEnabled: false,
          },
        });

        setLoading(false);
      } catch (error) {
        console.log('Error fetching embed info:', error);
      }
    };

    fetchEmbedInfo();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="report-container">
        <PowerBIEmbed
          embedConfig={embedConfig}
          cssClassName="embed-container"
          getEmbeddedComponent={(embeddedReport) => {
            console.log('Report embedded:', embeddedReport);
          }}
        />
    </div>
  );
};

export default PowerBIReport;
