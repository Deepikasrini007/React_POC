import React, { useEffect } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import axios from 'axios';
import constants from './constants.json';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

ChartJS.register(ChartDataLabels);


export const options = {
  indexAxis: 'y',
  elements: {
    bar: {
      borderWidth: 1,
    },
  },
  responsive: true,
  plugins: {
    legend: {
      position: 'left',
      align: 'top',
      labels: {
        usePointStyle: true, 
        pointStyle: 'circle',
        // pointStyleWidth: 20,
        font: {
            size: 12
        },
        boxHeight: 6,
        boxWidth: 6,
        generateLabels: (chart) => {
            return [
                {
                    text: 'Online',
                    fillStyle: 'turquoise'
                },
                {
                    text: 'Social Media',
                    fillStyle: 'black'
                },
                {
                    text: 'Outlet',
                    fillStyle: 'red'
                },
                {
                    text: 'Stores',
                    fillStyle: 'orange'
                }
            ]
        }
      }
    },
    title: {
      display: false,
      text: 'Total Sales by Product and Channel',
      position: 'top'
    },
    datalabels: {
        color: '#fff',
        font: {
            weight: 'bold'
        },
        formatter: (value, context) => {
            return `$${value}`;
        }
    }
  },
  scales: {
    x: {
      grid: {
        display: false
      }
    },
    y: {
      grid: {
        display: false
      }
    }
  }
};

const labels = ['Maximus UM -70', 'Maximus UM -61', 'Maximus UM -78', 'Maximus UM -70', 'Maximus UM -7', 'Maximus UM -82', 'Maximus UM -23', 'Maximus UM -0', 'Maximus UM -70', 'Maximus UM -61', 'Maximus UM -78', 'Maximus UM -70', 'Maximus UM -7', 'Maximus UM -82', 'Maximus UM -23', 'Maximus UM -0', 'Maximus UM -70', 'Maximus UM -61', 'Maximus UM -78', 'Maximus UM -70', 'Maximus UM -7', 'Maximus UM -82', 'Maximus UM -23', 'Maximus UM -0'];
const numbers = [2359, 2118, 1917, 1066, 715, 568, 463, 453, 429, 393, 390, 369, 367, 356, 348, 337, 301, 268, 256, 255, 252, 246, 215, 201];
const colors = ['turquoise', 'orange', 'black', 'red'];

export const data = {
  labels: labels,
  datasets: [
    {
      label: "Dataset",
      data: numbers,
      backgroundColor: colors,
      barThickness: 20,
      categoryPercentage: 0.8, // notice here 
      barPercentage: 0.8,  // notice here 
      
    }
  ]
};

function View3({ accessToken }) {

  console.log(accessToken, 'accessToken1')

  const body = {
        "queries": [
            {
                "query": "EVALUATE ALL(Product)"
            }
        ]
    };

    

    const token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik1HTHFqOThWTkxvWGFGZnBKQ0JwZ0I0SmFLcyIsImtpZCI6Ik1HTHFqOThWTkxvWGFGZnBKQ0JwZ0I0SmFLcyJ9.eyJhdWQiOiJodHRwczovL2FuYWx5c2lzLndpbmRvd3MubmV0L3Bvd2VyYmkvYXBpIiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvYWFhODRhMTUtYjJiNS00MTZjLWJkOGMtZjM4MDYxOTAxMTI5LyIsImlhdCI6MTcxOTkxMTQyNiwibmJmIjoxNzE5OTExNDI2LCJleHAiOjE3MTk5MTYyOTgsImFjY3QiOjAsImFjciI6IjEiLCJhaW8iOiJBVFFBeS84WEFBQUFEY2pDM0pjWFZqNVhWc29ZKzdtZXVTbXBvakpybTYwZmtoSXNkUjhxeDNKT3BkR2poTzY1TU10aG9BOG1jdlhZIiwiYW1yIjpbInB3ZCJdLCJhcHBpZCI6Ijg3MWMwMTBmLTVlNjEtNGZiMS04M2FjLTk4NjEwYTdlOTExMCIsImFwcGlkYWNyIjoiMCIsImlkdHlwIjoidXNlciIsImlwYWRkciI6IjI3LjQuMC4xMzgiLCJuYW1lIjoiQXJ1biBzcmluaXZhcyBWIiwib2lkIjoiMTdjYzUyMjUtYWNhZC00YjIzLTk4ZGQtNWZhN2IxZGM1NjM1IiwicHVpZCI6IjEwMDMyMDAzOUE0NDZCODgiLCJyaCI6IjAuQWI0QUZVcW9xcld5YkVHOWpQT0FZWkFSS1FrQUFBQUFBQUFBd0FBQUFBQUFBQUMtQUp3LiIsInNjcCI6InVzZXJfaW1wZXJzb25hdGlvbiIsInNpZ25pbl9zdGF0ZSI6WyJrbXNpIl0sInN1YiI6InlEZUtERGY0M2dVMlVOZk1NMjYwX2IxcEg0TS10MlA1MGNDZjljRmI2WTgiLCJ0aWQiOiJhYWE4NGExNS1iMmI1LTQxNmMtYmQ4Yy1mMzgwNjE5MDExMjkiLCJ1bmlxdWVfbmFtZSI6ImFzcmluaXZhc0BwYml0ZWFtcG9jLm9ubWljcm9zb2Z0LmNvbSIsInVwbiI6ImFzcmluaXZhc0BwYml0ZWFtcG9jLm9ubWljcm9zb2Z0LmNvbSIsInV0aSI6IjdndkRhN01GRkV5S1RYbDd2TWd1QVEiLCJ2ZXIiOiIxLjAiLCJ3aWRzIjpbImI3OWZiZjRkLTNlZjktNDY4OS04MTQzLTc2YjE5NGU4NTUwOSJdLCJ4bXNfaWRyZWwiOiIxIDEwIn0.vb6pcMLe6PRda5kgnETkAluhymJ43tLAoiHFhpmwkrvcHCRvxLQ535_bOg6w1GtnU1cV_nPrSfW6iTqL3vKDygWxteLhadnedHiI_krCXE4wBHt3vVbjru2eKzufqTKWQLymC0XXkoCMbrImbWn3lfG1OlR0h6rZOw50d3-GtD2CB4W421xTXzVpZ2tCR9c1fHBwzcZTf0J2Vk_CGd6dJsHx04a5oH6CxURosF6cy8q9j6V57ioC0GGCVxruDGsvc_oQoA7tS4oShO0GFCMoaLv9UqF1eJPd_H1yeUleAT3STdHI3fZpXUUB3J0IYaz9eACRg-6FywMA1BlVTScaWA';
    

  useEffect(() => {
    axios.post(`https://api.powerbi.com/v1.0/myorg/datasets/${constants.datasetId}/executeQueries`, JSON.stringify(body), {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    }).then(res => {
      console.loer(res, 'res')
    }).catch(err => {
      console.log(err, 'err')
    })
  }, []);

  return (
    <>
        <h5>Total Sales by Product and Channel</h5>
        <Bar options={options} data={data} />
    </>
  );
}

export default View3;