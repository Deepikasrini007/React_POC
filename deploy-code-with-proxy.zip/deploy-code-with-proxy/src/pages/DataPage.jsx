import { useEffect, useState } from "react";
import Typography from "@mui/material/Typography";

// Msal imports
import { MsalAuthenticationTemplate, useMsal, UnauthenticatedTemplate } from "@azure/msal-react";
import { InteractionStatus, InteractionType, InteractionRequiredAuthError } from "@azure/msal-browser";
import { loginRequest } from "../authConfig";

// Sample app imports
import { ProfileData } from "../ui-components/ProfileData";
import Data from "../ui-components/Data";
import { Loading } from "../ui-components/Loading";
import { ErrorComponent } from "../ui-components/ErrorComponent";
import { callMsGraph } from "../utils/MsGraphApiCall";

// Material-ui imports
import Paper from "@mui/material/Paper";

const ProfileContent = () => {
    const { instance, inProgress } = useMsal();
    const [graphData, setGraphData] = useState(null);
    const [accessToken, setAccessToken] = useState('');

    const request = {
        scopes: ["User.Read"],
    };

    useEffect(() => {
        instance.acquireTokenSilent(request).then(res => {
            console.log(res, 'case1')
            setAccessToken(res.accessToken);
        }).catch(err => {
            console.log(err, 'case2');
            setAccessToken('')
        })
    }, []);

    useEffect(() => {
        if (!graphData && inProgress === InteractionStatus.None) {
            callMsGraph().then(response => setGraphData(response)).catch((e) => {
                if (e instanceof InteractionRequiredAuthError) {
                    instance.acquireTokenRedirect({
                        ...loginRequest,
                        account: instance.getActiveAccount()
                    });
                }
            });
        }
    }, [inProgress, graphData, instance]);
  
    return (
        <Paper style={{ width: '95%' }}>
            { graphData ? <Data graphData={graphData} accessToken={accessToken} /> : null }
        </Paper>
    );
};

export function DataPage() {
    const authRequest = {
        ...loginRequest
    };

    return (
        <>
            <MsalAuthenticationTemplate 
                interactionType={InteractionType.Popup} 
                authenticationRequest={authRequest} 
                errorComponent={ErrorComponent} 
                loadingComponent={Loading}
            >
                <ProfileContent />
            </MsalAuthenticationTemplate>
            <UnauthenticatedTemplate>
                <Typography variant="h6">
                <center>Please sign-in.</center>
                </Typography>
            </UnauthenticatedTemplate>
        </>
    );
};