import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export const options = {
  indexAxis: 'y',
  elements: {
    bar: {
      borderWidth: 2,
    },
  },
  responsive: true,
  plugins: {
    legend: {
      position: 'right',
    },
    title: {
      display: true,
      text: 'Total Sales by Product and Channel',
    },
  },
};

const labels = ['Maximus UM -70', 'Maximus UM -61', 'Maximus UM -78', 'Maximus UM -70', 'Maximus UM -7', 'Maximus UM -82', 'Maximus UM -23', 'Maximus UM -0', 'Maximus UM -70', 'Maximus UM -61', 'Maximus UM -78', 'Maximus UM -70', 'Maximus UM -7', 'Maximus UM -82', 'Maximus UM -23', 'Maximus UM -0', 'Maximus UM -70', 'Maximus UM -61', 'Maximus UM -78', 'Maximus UM -70', 'Maximus UM -7', 'Maximus UM -82', 'Maximus UM -23', 'Maximus UM -0'];
const numbers = [2359, 2118, 1917, 1066, 715, 651, 599, 591, 568, 463, 453, 429, 393, 390, 369, 367, 356, 348, 337, 301, 268, 256, 255, 252, 246];
const colors = ['green', 'green', 'green', 'green', 'yellow', 'green', 'black', 'green'];

export const data = {
  labels: labels,
  datasets: [
    {
      label: 'Dataset 2',
      data: numbers,
      backgroundColor: colors,
      barThickness: 20,
      categoryPercentage: 0.8, // notice here 
      barPercentage: 0.8,  // notice here 
      
    }
  ]
};

function View3() {
  return <Bar options={options} data={data} />;
}

export default View3;