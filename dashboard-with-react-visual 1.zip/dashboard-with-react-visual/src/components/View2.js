import React from 'react';

import { PowerBIEmbed } from 'powerbi-client-react';
import { models } from 'powerbi-client';

function View2() {
  return (
        <PowerBIEmbed
            embedConfig={{
            type: 'visual',   // Supported types: report, dashboard, tile, visual, qna, paginated report and create
            id: '28a8216b-f6e5-48d9-97ba-374948f86c42',
            pageName: 'ReportSectione0912ffb2ba909ea50d0',
            visualName:'VisualContainer4',
            embedUrl: 'https://app.powerbi.com/reportEmbed?reportId=28a8216b-f6e5-48d9-97ba-374948f86c42&groupId=decf61a4-56cd-4cd7-94d3-2e8f182ae0ef&w=2&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly9XQUJJLVNPVVRILUVBU1QtQVNJQS1yZWRpcmVjdC5hbmFseXNpcy53aW5kb3dzLm5ldCIsImVtYmVkRmVhdHVyZXMiOnsidXNhZ2VNZXRyaWNzVk5leHQiOnRydWV9fQ%3d%3d',
            accessToken:'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IkwxS2ZLRklfam5YYndXYzIyeFp4dzFzVUhIMCIsImtpZCI6IkwxS2ZLRklfam5YYndXYzIyeFp4dzFzVUhIMCJ9.eyJhdWQiOiJodHRwczovL2FuYWx5c2lzLndpbmRvd3MubmV0L3Bvd2VyYmkvYXBpIiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvZTljYjNjODAtNDE1Ni00YzM5LWE3ZmUtNjhmZTQyN2EzZDQ2LyIsImlhdCI6MTcxNjk4NDc0MSwibmJmIjoxNzE2OTg0NzQxLCJleHAiOjE3MTY5ODk1MzUsImFjY3QiOjAsImFjciI6IjEiLCJhaW8iOiJBVFFBeS84V0FBQUF0TkR6dUNoSCswNnRjNVRHY1hnUlJiR2NtTzk0VEQ0WWk3Rlo0STRtbzdFNkN1SGUxWkRqb2VOWUtaNWY4ekpRIiwiYW1yIjpbInB3ZCJdLCJhcHBpZCI6Ijg3MWMwMTBmLTVlNjEtNGZiMS04M2FjLTk4NjEwYTdlOTExMCIsImFwcGlkYWNyIjoiMCIsImZhbWlseV9uYW1lIjoiRnV0YW5lIiwiZ2l2ZW5fbmFtZSI6IlByYXRpayIsImlwYWRkciI6IjI0MDU6MjAxOjEwMTk6MzAwNDpmZGFkOjhmZjo4OTMwOjcxNTIiLCJuYW1lIjoiUHJhdGlrIEdhbmVzaCBGdXRhbmUiLCJvaWQiOiIxYTdiNDNmMi1lMDMyLTQ5NjEtOWMzNS1iMjc1NzVmN2M5YjUiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtMzYzOTE2ODE2MC0zOTcyODAzNTQ2LTg1NjQxNTYyOC01Mzc0NyIsInB1aWQiOiIxMDAzMjAwMkY5N0U2NDIxIiwicmgiOiIwLkFYSUFnRHpMNlZaQk9VeW5fbWotUW5vOVJna0FBQUFBQUFBQXdBQUFBQUFBQUFCeUFNYy4iLCJzY3AiOiJ1c2VyX2ltcGVyc29uYXRpb24iLCJzaWduaW5fc3RhdGUiOlsia21zaSJdLCJzdWIiOiJvTDUtdERrU2xFQUFGNDhld25XV0g4RzdWZ01iNGxrV3VuV3BVR1BqZC1nIiwidGlkIjoiZTljYjNjODAtNDE1Ni00YzM5LWE3ZmUtNjhmZTQyN2EzZDQ2IiwidW5pcXVlX25hbWUiOiJwZ2Z1dGFuZUBhbHRpbWV0cmlrLmNvbSIsInVwbiI6InBnZnV0YW5lQGFsdGltZXRyaWsuY29tIiwidXRpIjoiMUhGbFI0T0Q0RW1YX3ROYWp5akdBQSIsInZlciI6IjEuMCIsIndpZHMiOlsiYjc5ZmJmNGQtM2VmOS00Njg5LTgxNDMtNzZiMTk0ZTg1NTA5Il19.TYy7El7b4d4vu1dutk4hiFWTh1DRlifocvpUsL0F4bxbp0x7FPWahl_hL78FJch6AwvLzq038-Sb3P3TmzWltleM6wFzchIwMRyP0Xux6ItfCBpGZf3MS3Qs-UKKBuCd82P-tDvyBcmCYJymwxsxc8URpgmK6YHhJEPPka7KfjJMdbtuE-Gvv3z-6oPLrSBcc19dEOyVmx3BFoNmVzCn_qPg7r9O-rV5VkxQ-aPmDAXatZ8H_PDi0GGaAU1NhnH4nGmEvybtesSVpdQkvqYqZ_qzxStHdiBa7DwdpZMIY5l6sX3-wO2LjBHluZ-u8PeT_35iP5vXDAP2t0GdWSQYAg',
            tokenType: models.TokenType.Aad, // Use models.TokenType.Aad for SaaS embed
            settings: {
                panes: {
                filters: {
                    expanded: false,
                    visible: true
                }
                }
            }
            }}

            eventHandlers={
            new Map([
                ['loaded', function () { console.log('Report loaded'); }],
                ['rendered', function () { console.log('Report rendered'); }],
                ['error', function (event) { console.log(event.detail); }],
                ['visualClicked', () => console.log('visual clicked')],
                ['pageChanged', (event) => console.log(event)],
            ])
            }

            cssClassName={"Embed-container"}

            getEmbeddedComponent={(embeddedReport) => {
            window.report = embeddedReport ;
            }}
        />
  );
}

export default View2; 