import './App.css';
import React , { useState } from 'react';
import Content from './components/Content';
import Filters from './components/Filters';
import MenuHeader from './components/Header';

function App() {
  const [activeView, setActiveView] = useState('nfcm');
  return (
    <>
      <MenuHeader 
        activeView={activeView} 
        setActiveView={setActiveView} 
      />
      <Filters />
      <Content 
        activeView={activeView} 
      />
    </>
  );
}

export default App;
