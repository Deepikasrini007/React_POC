import { useNavigate } from 'react-router-dom';

import { AppBar, Box, Typography, IconButton } from '@mui/material';
import Altimetrik from '../assets/altimetrik.png'

import Login from './LoginMenu';

const Banner = () => {
  let navigate = useNavigate();

  return (
    <AppBar position="sticky" sx={{ zIndex: 2, height: "48px", py: 0.5, pl: 2, background: "linear-gradient(to right bottom, #00498D, #02386E)" }} >
      <Box sx={{ display: 'flex' }} >
        <IconButton onClick={() => { navigate("/") }} size="large" edge="start" color="inherit" aria-label="menu" sx={{ width: "180px", height: "36px" }} >
          <img style={{display:"flex", width: "150px", height: "auto"}} src={Altimetrik} alt="Altimetrik" />
        </IconButton>
        <Typography variant="h5" flexGrow={0} sx={{ ml: 1, pt: 0.5 }} >Power BI Embedded (User owns Data)</Typography>
        <Login />
      </Box>


    </AppBar>
  )
}

export default Banner;