import React, { useEffect, useState } from 'react';
import PowerBiService from '../../services/PowerBiService'
import { Container, Table, TableHead, TableBody, TableRow, TableCell, tableCellClasses, Box, TablePagination, TableContainer, FormControl, InputLabel, Select, MenuItem, Checkbox, ListItemText, OutlinedInput } from '@mui/material';
import { styled } from '@mui/material/styles';
import DataLoading from '../DataLoading';
import DownloadCsv from '../DownloadCsv';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250,
        },
    },
};


function View3() {
    const [rows, setRows] = useState([])
    const [rowsFiltered, setFilterRow] = useState([])
    const [columns, setColumns] = useState([])
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);
    const [loading, setLoading] = React.useState(false);
    const [category, setCategory] = useState([])
    const [filter, setFilter] = useState([])

    const handleChangePage = (event: unknown, newPage: number) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };

    useEffect(() => {
        if (filter[0]) {
            let rowsfil: any = []
            rows.forEach((row) => {
                if (filter.findIndex(item => item === row["Product[Segment]"]) >= 0) {
                    rowsfil = [...rowsfil, row]
                }
            })
            setFilterRow(rowsfil)
        } else {
            setFilterRow(rows)
        }

    }, [filter, rows])

    const getReportInfo = async () => {
        setLoading(true);
        const datasets = await PowerBiService.GetDatasets('b81f2141-5e27-489e-8d87-d506b1e3a3ab')
        const data = await PowerBiService.GetDatasetsData(datasets[0]?.id, "Product")
        const data2 = await PowerBiService.GetDatasetsData(datasets[0]?.id, "Category")
        console.log({ datasets, data })
        setRows(data?.results[0]?.tables[0]?.rows[0] ? data?.results[0]?.tables[0]?.rows : [])
        setColumns(data?.results[0]?.tables[0]?.rows[0] ? Object.keys(data?.results[0]?.tables[0]?.rows[0]) : [])
        setLoading(false);
        const categoryObj = data2?.results[0]?.tables[0]?.rows[0] ? data2?.results[0]?.tables[0]?.rows : []
        const category = categoryObj.map((cate: any) => {
            return cate["Category[Category]"]
        })
        setCategory(category)
        console.log({ data2, category, categoryObj })


    }


    const StyledTableRow = styled(TableRow)(({ theme }) => ({
        "&:nth-of-type(odd)": {
            backgroundColor: theme.palette.action.hover
        },
        // hide last border
        "&:last-child td, &:last-child th": {
            border: 0
        }
    }));

    const StyledTableCell = styled(TableCell)(({ theme }) => ({
        [`&.${tableCellClasses.head}`]: {
            backgroundColor: theme.palette.common.black,
            color: theme.palette.common.white
        },
        [`&.${tableCellClasses.body}`]: {
            fontSize: 14
        }
    }));

    const dropHandler = () => {
        console.log("dropping");
    };

    const dragEnterHandeler = () => {
        console.log("drag enter");
    };

    useEffect(() => {
        getReportInfo()
    }, [])

    if (loading) {
        return <Container sx={{ margin: "500px" }} maxWidth={false}><DataLoading></DataLoading></Container>
    }

    return (
        <Container maxWidth={false}>


            <Table sx={{ minWidth: 450, marginTop: '20px' }}>
                <TableHead className='sticky-header'>
                    <StyledTableRow>
                        <DownloadCsv data={rows}></DownloadCsv>
                        <FormControl sx={{ backgroundColor: "white" }} fullWidth>
                            <InputLabel id="demo-simple-select-label">Category</InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                multiple
                                value={filter}
                                label="filter"
                                onChange={(event) => {
                                    console.log({ event })

                                    setFilter(event.target.value as Array<string>)

                                }}
                                input={<OutlinedInput label="Tag" />}
                                renderValue={(selected) => selected.map((x) => x).join(', ')}
                                MenuProps={MenuProps}
                            >
                                {category.map((prod) => {
                                    return (<MenuItem key={prod} value={prod}>
                                        <Checkbox
                                            checked={
                                                filter.findIndex(item => item === prod) >= 0
                                            }
                                        />
                                        <ListItemText primary={prod} />
                                    </MenuItem>)
                                })
                                }
                            </Select>
                        </FormControl>
                    </StyledTableRow>
                    <StyledTableRow>
                        {columns.map((columns) => (
                            <StyledTableCell sx={{ width: '50px' }}>{columns.slice(7).replace('[', '').replace(']', '')}</StyledTableCell>
                        ))}
                    </StyledTableRow>
                </TableHead>
                <TableBody>
                    {rowsFiltered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row, index) => (
                        <StyledTableRow
                            draggable={true}
                            // onDragStart={dragHandler}
                            onDragOver={dragEnterHandeler}
                            onDrop={dropHandler}
                            id={"sdas"}
                            key={index}
                            sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                        >
                            {Object.values(row).map((value: string) => {

                                return (<StyledTableCell sx={{ width: '50px' }} component="th" scope="row">
                                    {value}
                                </StyledTableCell>)
                            })
                            }

                        </StyledTableRow>
                    ))}
                </TableBody>
            </Table>
            <TablePagination
                className='sticky-footer'
                rowsPerPageOptions={[10, 25, 100]}
                component="div"
                count={rows.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
            />

        </Container>
    );
}

export default View3;