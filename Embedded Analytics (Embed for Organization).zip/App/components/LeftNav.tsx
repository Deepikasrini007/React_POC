import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Button, Drawer, SxProps } from '@mui/material';
import { useIsAuthenticated } from '@azure/msal-react';

const LeftNav = () => {
    const navigate = useNavigate();
    const isAuthenticated = useIsAuthenticated();

    const expandedLeftNavWidth = 280;
    const colapsedLeftNavWidth = 48;
    const [leftNavWidth, setLeftNavWidth] = useState(expandedLeftNavWidth);
    const [leftNavExpanded, setLeftNavExpanded] = useState(true);

    const leftNavTopBoxProps: SxProps = { width: 1, color: "white", backgroundColor: "white", mt: "48px" };

    const leftNavOuterBoxProps: SxProps = { width: 1, display: "flex", flexDirection: 'column',paddingTop:'20px' };

    const leftNavInnerBoxRightProps: SxProps = { py: 0, padding: '10px', width: leftNavExpanded ? 1 : 0, backgroundColor: "white" };


    const leftNavListProps: SxProps = {
        mt: 0, pt: 0, border: 0, fontSize: "14px", width: 1, my: 0, py: 0, color: "black"
    };

    const toggleLeftNavWidth = () => {
        if (leftNavExpanded) {
            setLeftNavExpanded(false);
            setLeftNavWidth(colapsedLeftNavWidth);
        }
        else {
            setLeftNavExpanded(true);
            setLeftNavWidth(expandedLeftNavWidth);
        }
    };

    return (
        <Drawer variant='permanent' anchor='left'
            sx={{ width: leftNavWidth, display: isAuthenticated ? "flex" : "none", zIndex: 1, pt: "84px", pb: 3 }}
            PaperProps={{ sx: { width: leftNavWidth, backgroundColor: "white" } }}  >
            <Box sx={leftNavTopBoxProps} >
                <Box sx={leftNavOuterBoxProps} >
                    <Box sx={leftNavInnerBoxRightProps}>
                        <Box sx={{ marginLeft: "12px", marginRight: "12px", pt: "2px", backgroundColor: (document.URL.includes('/report')) ? "lightblue" : "white" }}>
                            <Button sx={leftNavListProps} onClick={() => { navigate('report') }} color="inherit">Embedded report</Button>
                        </Box>
                    </Box>
                    <Box sx={leftNavInnerBoxRightProps}>
                        <Box sx={{ marginRight: "12px", marginLeft: "12px", pt: "2px", backgroundColor: (document.URL.includes('/visual')) ? "lightblue" : "white" }}>
                            <Button sx={leftNavListProps} onClick={() => { navigate('visual') }} color="inherit">Embedded visual</Button>
                        </Box>

                    </Box>
                    <Box sx={leftNavInnerBoxRightProps}>
                        <Box sx={{ marginRight: "12px", marginLeft: "12px", pt: "2px", backgroundColor: (document.URL.includes('/custom-visual')) ? "lightblue" : "white" }}>
                            <Button sx={leftNavListProps} onClick={() => { navigate('custom-visual') }} color="inherit">React visual</Button>
                        </Box>

                    </Box>
                </Box>
            </Box>
        </Drawer>
    )
}

export default LeftNav;