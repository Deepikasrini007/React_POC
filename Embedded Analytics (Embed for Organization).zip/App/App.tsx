import { BrowserRouter } from "react-router-dom";
import PageLayout from './components/PageLayout'
import { CssBaseline } from '@mui/material';
import './App.css'

const App = () => {

  return (
    <>
      <CssBaseline />
      <BrowserRouter>
        <PageLayout />
      </BrowserRouter>

    </>
  )
}

export default App;