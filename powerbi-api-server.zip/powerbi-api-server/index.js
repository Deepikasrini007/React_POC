const express = require('express');
const axios = require('axios');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const port = process.env.PORT || 5000;

const tenantId = process.env.TENANT_ID;
const clientId = process.env.CLIENT_ID;
const clientSecret = process.env.CLIENT_SECRET;
const workspaceId = process.env.WORKSPACE_ID;
const reportId = process.env.REPORT_ID;
const datasetId = process.env.DATASET_ID;
const authority = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;
const scope = 'https://analysis.windows.net/powerbi/api/.default';
// const scope1 = 'api://d6590368-4a63-44fe-97a3-91d321181fb2/.default';

app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
});

// Function to get Azure AD access token
const getAccessToken = async () => {
  const params = new URLSearchParams();
  params.append('grant_type', 'client_credentials');
  params.append('client_id', clientId);
  params.append('client_secret', clientSecret);
  params.append('scope', scope);

  try {
    const response = await axios.post(authority, params, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });
    return response.data.access_token;
  } catch (error) {
    console.error('Error fetching access token:', error.response?.data || error.message);
    throw error;
  }
};

// https://api.powerbi.com/v1.0/myorg/groups/b81f2141-5e27-489e-8d87-d506b1e3a3ab/reports/239129af-6bbb-457f-8a8c-f03cff704af9/GenerateToken

// Function to generate Power BI embed token and URL
const generateEmbedTokenAndUrl = async (accessToken) => {
  const reportUrl = `https://api.powerbi.com/v1.0/myorg/groups/${workspaceId}/reports/${reportId}`;
  const tokenUrl = `https://api.powerbi.com/v1.0/myorg/groups/${workspaceId}/reports/${reportId}/GenerateToken`;

  console.log(accessToken, 'accessToken123');
  
  try {
    const reportResponse = await axios.get(reportUrl, {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
      },
    });
    const embedUrl = reportResponse.data.embedUrl;
    
    const tokenResponse = await axios.post(tokenUrl, { accessLevel: 'View' }, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`,
      },
    });
    const embedToken = tokenResponse.data.token;

    return { embedUrl, embedToken };
  } catch (error) {
    console.error('Error generating embed token and URL:', error.response?.data || error.message);
    throw error;
  }
};

app.get('/api/embed-info', async (req, res) => {
  try {
    const accessToken = await getAccessToken();
    console.log(accessToken)
    const { embedUrl, embedToken } = await generateEmbedTokenAndUrl(accessToken);
    res.json({ embedUrl, embedToken });
  } catch (error) {
    res.status(500).send('Error generating embed token and URL');
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
