import React from 'react';
import { Icon, Label } from 'semantic-ui-react'

function Filters() {
    return (
        <div style={{ padding: '5px', backgroundColor: '#f4f4f4' }}>
            <Label as='a' size='large' className='filter-label'>
                View
            <Icon name='delete' />
            </Label>
            <Label as='a' size='large' className='filter-label'>
                Month Year
            <Icon name='delete' />
            </Label>
            <Label as='a' size='large' className='filter-label'>
                Filter 3
            <Icon name='delete' />
            </Label>
        </div>
    );
}

export default Filters;