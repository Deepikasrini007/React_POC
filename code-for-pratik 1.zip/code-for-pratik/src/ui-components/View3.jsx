import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import ChartDataLabels from 'chartjs-plugin-datalabels';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

ChartJS.register(ChartDataLabels);


export const options = {
  indexAxis: 'y',
  elements: {
    bar: {
      borderWidth: 1,
    },
  },
  responsive: true,
  plugins: {
    legend: {
      position: 'left',
      align: 'top',
      labels: {
        usePointStyle: true, 
        pointStyle: 'circle',
        // pointStyleWidth: 20,
        font: {
            size: 12
        },
        boxHeight: 6,
        boxWidth: 6,
        generateLabels: (chart) => {
            return [
                {
                    text: 'Online',
                    fillStyle: 'turquoise'
                },
                {
                    text: 'Social Media',
                    fillStyle: 'black'
                },
                {
                    text: 'Outlet',
                    fillStyle: 'red'
                },
                {
                    text: 'Stores',
                    fillStyle: 'orange'
                }
            ]
        }
      }
    },
    title: {
      display: false,
      text: 'Total Sales by Product and Channel',
      position: 'top'
    },
    datalabels: {
        color: '#fff',
        font: {
            weight: 'bold'
        },
        formatter: (value, context) => {
            return `$${value}`;
        }
    }
  },
  scales: {
    x: {
      grid: {
        display: false
      }
    },
    y: {
      grid: {
        display: false
      }
    }
  }
};

const labels = ['Maximus UM -70', 'Maximus UM -61', 'Maximus UM -78', 'Maximus UM -70', 'Maximus UM -7', 'Maximus UM -82', 'Maximus UM -23', 'Maximus UM -0', 'Maximus UM -70', 'Maximus UM -61', 'Maximus UM -78', 'Maximus UM -70', 'Maximus UM -7', 'Maximus UM -82', 'Maximus UM -23', 'Maximus UM -0', 'Maximus UM -70', 'Maximus UM -61', 'Maximus UM -78', 'Maximus UM -70', 'Maximus UM -7', 'Maximus UM -82', 'Maximus UM -23', 'Maximus UM -0'];
const numbers = [2359, 2118, 1917, 1066, 715, 568, 463, 453, 429, 393, 390, 369, 367, 356, 348, 337, 301, 268, 256, 255, 252, 246, 215, 201];
const colors = ['turquoise', 'orange', 'black', 'red'];

export const data = {
  labels: labels,
  datasets: [
    {
      label: "Dataset",
      data: numbers,
      backgroundColor: colors,
      barThickness: 20,
      categoryPercentage: 0.8, // notice here 
      barPercentage: 0.8,  // notice here 
      
    }
  ]
};

function View3() {
  return (
    <>
        <h5>Total Sales by Product and Channel</h5>
        <Bar options={options} data={data} />
    </>
  );
}

export default View3;